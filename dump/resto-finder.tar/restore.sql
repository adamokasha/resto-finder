--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 12.2
-- Dumped by pg_dump version 12.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "resto-finder";
--
-- Name: resto-finder; Type: DATABASE; Schema: -; Owner: postgres
--

CREATE DATABASE "resto-finder" WITH TEMPLATE = template0 ENCODING = 'UTF8' LC_COLLATE = 'C' LC_CTYPE = 'C';


ALTER DATABASE "resto-finder" OWNER TO postgres;

\connect -reuse-previous=on "dbname='resto-finder'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: Blacklist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Blacklist" (
    id integer NOT NULL,
    username character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "UserId" integer NOT NULL,
    "RestaurantId" integer NOT NULL
);


ALTER TABLE public."Blacklist" OWNER TO postgres;

--
-- Name: Blacklist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Blacklist_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Blacklist_id_seq" OWNER TO postgres;

--
-- Name: Blacklist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Blacklist_id_seq" OWNED BY public."Blacklist".id;


--
-- Name: BusinessHours; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."BusinessHours" (
    id integer NOT NULL,
    day integer,
    open time without time zone,
    close time without time zone,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "RestaurantId" integer NOT NULL
);


ALTER TABLE public."BusinessHours" OWNER TO postgres;

--
-- Name: BusinessHours_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."BusinessHours_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."BusinessHours_id_seq" OWNER TO postgres;

--
-- Name: BusinessHours_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."BusinessHours_id_seq" OWNED BY public."BusinessHours".id;


--
-- Name: Favourite; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Favourite" (
    id integer NOT NULL,
    username character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL,
    "UserId" integer NOT NULL,
    "RestaurantId" integer NOT NULL
);


ALTER TABLE public."Favourite" OWNER TO postgres;

--
-- Name: Favourite_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Favourite_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Favourite_id_seq" OWNER TO postgres;

--
-- Name: Favourite_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Favourite_id_seq" OWNED BY public."Favourite".id;


--
-- Name: Restaurant; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."Restaurant" (
    id integer NOT NULL,
    name character varying(255),
    city character varying(255),
    province character varying(255),
    "postalCode" character varying(255),
    country character varying(255),
    "cuisineType" character varying(255),
    distance integer,
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."Restaurant" OWNER TO postgres;

--
-- Name: Restaurant_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."Restaurant_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."Restaurant_id_seq" OWNER TO postgres;

--
-- Name: Restaurant_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."Restaurant_id_seq" OWNED BY public."Restaurant".id;


--
-- Name: User; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public."User" (
    id integer NOT NULL,
    username character varying(255),
    "firstName" character varying(255),
    "lastName" character varying(255),
    city character varying(255),
    province character varying(255),
    country character varying(255),
    "createdAt" timestamp with time zone NOT NULL,
    "updatedAt" timestamp with time zone NOT NULL
);


ALTER TABLE public."User" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public."User_id_seq"
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public."User_id_seq" OWNER TO postgres;

--
-- Name: User_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public."User_id_seq" OWNED BY public."User".id;


--
-- Name: Blacklist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blacklist" ALTER COLUMN id SET DEFAULT nextval('public."Blacklist_id_seq"'::regclass);


--
-- Name: BusinessHours id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BusinessHours" ALTER COLUMN id SET DEFAULT nextval('public."BusinessHours_id_seq"'::regclass);


--
-- Name: Favourite id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favourite" ALTER COLUMN id SET DEFAULT nextval('public."Favourite_id_seq"'::regclass);


--
-- Name: Restaurant id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Restaurant" ALTER COLUMN id SET DEFAULT nextval('public."Restaurant_id_seq"'::regclass);


--
-- Name: User id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User" ALTER COLUMN id SET DEFAULT nextval('public."User_id_seq"'::regclass);


--
-- Data for Name: Blacklist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Blacklist" (id, username, "createdAt", "updatedAt", "UserId", "RestaurantId") FROM stdin;
\.
COPY public."Blacklist" (id, username, "createdAt", "updatedAt", "UserId", "RestaurantId") FROM '$$PATH$$/3209.dat';

--
-- Data for Name: BusinessHours; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."BusinessHours" (id, day, open, close, "createdAt", "updatedAt", "RestaurantId") FROM stdin;
\.
COPY public."BusinessHours" (id, day, open, close, "createdAt", "updatedAt", "RestaurantId") FROM '$$PATH$$/3211.dat';

--
-- Data for Name: Favourite; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Favourite" (id, username, "createdAt", "updatedAt", "UserId", "RestaurantId") FROM stdin;
\.
COPY public."Favourite" (id, username, "createdAt", "updatedAt", "UserId", "RestaurantId") FROM '$$PATH$$/3213.dat';

--
-- Data for Name: Restaurant; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."Restaurant" (id, name, city, province, "postalCode", country, "cuisineType", distance, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."Restaurant" (id, name, city, province, "postalCode", country, "cuisineType", distance, "createdAt", "updatedAt") FROM '$$PATH$$/3207.dat';

--
-- Data for Name: User; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public."User" (id, username, "firstName", "lastName", city, province, country, "createdAt", "updatedAt") FROM stdin;
\.
COPY public."User" (id, username, "firstName", "lastName", city, province, country, "createdAt", "updatedAt") FROM '$$PATH$$/3205.dat';

--
-- Name: Blacklist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Blacklist_id_seq"', 1, false);


--
-- Name: BusinessHours_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."BusinessHours_id_seq"', 77, true);


--
-- Name: Favourite_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Favourite_id_seq"', 1, false);


--
-- Name: Restaurant_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."Restaurant_id_seq"', 11, true);


--
-- Name: User_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public."User_id_seq"', 4, true);


--
-- Name: Blacklist Blacklist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blacklist"
    ADD CONSTRAINT "Blacklist_pkey" PRIMARY KEY (id);


--
-- Name: BusinessHours BusinessHours_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BusinessHours"
    ADD CONSTRAINT "BusinessHours_pkey" PRIMARY KEY (id);


--
-- Name: Favourite Favourite_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favourite"
    ADD CONSTRAINT "Favourite_pkey" PRIMARY KEY (id);


--
-- Name: Restaurant Restaurant_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Restaurant"
    ADD CONSTRAINT "Restaurant_pkey" PRIMARY KEY (id);


--
-- Name: User User_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_pkey" PRIMARY KEY (id);


--
-- Name: User User_username_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_username_key" UNIQUE (username);


--
-- Name: User User_username_key1; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."User"
    ADD CONSTRAINT "User_username_key1" UNIQUE (username);


--
-- Name: Blacklist Blacklist_RestaurantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blacklist"
    ADD CONSTRAINT "Blacklist_RestaurantId_fkey" FOREIGN KEY ("RestaurantId") REFERENCES public."Restaurant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Blacklist Blacklist_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Blacklist"
    ADD CONSTRAINT "Blacklist_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: BusinessHours BusinessHours_RestaurantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."BusinessHours"
    ADD CONSTRAINT "BusinessHours_RestaurantId_fkey" FOREIGN KEY ("RestaurantId") REFERENCES public."Restaurant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favourite Favourite_RestaurantId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favourite"
    ADD CONSTRAINT "Favourite_RestaurantId_fkey" FOREIGN KEY ("RestaurantId") REFERENCES public."Restaurant"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: Favourite Favourite_UserId_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public."Favourite"
    ADD CONSTRAINT "Favourite_UserId_fkey" FOREIGN KEY ("UserId") REFERENCES public."User"(id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- PostgreSQL database dump complete
--

